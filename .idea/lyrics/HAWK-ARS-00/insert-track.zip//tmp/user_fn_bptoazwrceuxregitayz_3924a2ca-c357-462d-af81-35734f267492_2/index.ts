import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
serve(async (req)=>{
  const body = await req.json();
  const supabase = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"));
  const { error } = await supabase.from("arsenal").insert([
    body
  ]);
  if (error) {
    return new Response(JSON.stringify({
      success: false,
      error
    }), {
      status: 500
    });
  }
  return new Response(JSON.stringify({
    success: true
  }), {
    status: 200
  });
});
